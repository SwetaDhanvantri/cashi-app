// export const API_URL_PATHr = "https://thepinapp.in:4000/sapi/panel/";

// export const API_URL_PATH = "https://console.shopview.net/sapi/v4/"; //Live
// export const API_URL_PATH = "https://v3.shopview.net/sapi/v4/";
export const API_URL_PATH = "http://209.42.196.32:4400/sapi/panel/";  //Demo
// export const API_URL_PATH = "http://13.2.15.115:4000/sapi/panel/";

export const AUTHORIZATION_KEY = "RgUkXp2s5v8y5B8E7H1MbQeThVmYq3t6";
export const CALLING_APP = "ShopView";
export const CALLING_SOURCE = "Android";

