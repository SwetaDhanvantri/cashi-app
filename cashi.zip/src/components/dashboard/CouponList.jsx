
import { DataGrid, gridPageCountSelector, gridPageSelector, useGridSelector, useGridApiRef } from '@mui/x-data-grid';
import { Box, Button, Container, Typography, Pagination, PaginationItem, useMediaQuery, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { callPostApi } from '../../components/API/ApiCallFunction';
import { Add , Info } from '@mui/icons-material';
import Status from './StatusChip';
import ImagePreview from '../CommanComponents/ImagePreview';
import FullImgPreview from '../CommanComponents/FullImgPreview';
import GradientLoader from '../CommanComponents/GradientLoader';

function CustomPagination({ apiRef, isMobile }) {
  const page = useGridSelector(apiRef, gridPageSelector);
  const pageCount = useGridSelector(apiRef, gridPageCountSelector);
  return (
    <Pagination
      color="primary"
      variant="outlined"
      shape="rounded"
      page={page + 1}
      count={pageCount}
      renderItem={(props2) => <PaginationItem {...props2} disableRipple />}
      onChange={(event, value) => {
        apiRef.current.setPage(value - 1);
        if (isMobile && apiRef.current) {
          setTimeout(() => {
            apiRef.current.autosizeColumns({ includeHeaders: true });
          }, 0);
        }
      }}
    />
  );
}

const PAGE_SIZE = 10;

export default function CouponList() {
  const navigate = useNavigate();
  const apiRef = useGridApiRef();
  const [datar, setDatar] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalRowCount, setTotalRowCount] = useState(0);
  const [open, setOpen] = useState();
  const [selectedRow, setSelectedRow] = useState(null);
  const isMobile = useMediaQuery('(max-width:768px)');
  const user = JSON.parse(sessionStorage.getItem("user") || "{}");
  const [paginationModel, setPaginationModel] = useState({
    pageSize: PAGE_SIZE,
    page: 0,
  });
  useEffect(()=> {
  couponListApi(paginationModel.page + 1, PAGE_SIZE);
  }, [paginationModel.page]);

  // Autosize on mount and when screen size changes
  useEffect(() => {
    if (isMobile && apiRef.current) {
      apiRef.current.autosizeColumns({ includeHeaders: true });
    }
  }, [isMobile]);

  // Offer List API
const couponListApi = async (page, limit) => {
  try{ 
    setLoading(true)
   const storeid = user.store_info.store_id;
   const start = (page - 1) * limit + 1;
   const payload = { mod: "CASHI_OFFER_LIST", data_arr: { store_id: storeid, start: String(start), limit: String(limit) } };
   const apiResult = await callPostApi("cashi-offer", payload);

          // console.log("API Payload:", JSON.stringify(payload)); 
          // console.log("API Result:", JSON.stringify(apiResult));
  if (apiResult.status === "200" && Array.isArray(apiResult.data)) {
     setLoading(false)
    const formattedData = apiResult.data.map((item, index) => ({
      id: index + 1,
      offerId: item.offer_id || "NA",
      ctitle: item.offer_title || "NA",
      generate: item.max_coupon || "NA",
      maxOrder: item.min_order_amount || "NA",
      cvalue: item.coupon_coin || "NA",
      redemption: item.redemption_bid || "NA",
      distributionBid: item.distribution_bid || "NA",
      shortd: item.short_desc || "NA",
      longd: item.long_desc || "NA",
      activedate: item.offer_active || "NA",
      expdate: item.offer_expire || "NA",
      offimg: item.offer_logo  || "NA",
      status:  "1" ? "Approved" || "NA" : "Pending",
   
      issued:"0",
 
    }));

    setDatar(formattedData);
    setTotalRowCount(apiResult.total_count || 1000);
  } else {
        setDatar([]);
        setTotalRowCount(0);
  } 
  }catch (err) {
      console.error("Error fetching offers:", err);
    } finally {
      setLoading(false);
    }
  };


 const columns = [
    { field: 'id', headerName: 'Sr no.', flex: isMobile ? undefined : 0.7},
  { field: 'ctitle', headerName: 'Coupon Title',  flex: isMobile ? undefined : 1,},
   
  {
  field: "offimg",
  headerName: "Offer Image",
 flex: isMobile ? undefined : 1,
 renderCell: (params) => {
    if (!params.value || params.value === "NA") {
      return <Typography variant="body2">No Image</Typography>;
    }
    return (
        <FullImgPreview src={params.value} />
    );
  },
},
  { field: 'cvalue', headerName: 'Coupon value', flex: isMobile ? undefined : 1.3, align: 'center', },
  { field: 'activedate', headerName: 'Active Date', flex: isMobile ? undefined : 1 },
  { field: 'expdate', headerName: 'Expiry Date', flex: isMobile ? undefined : 1 },
 


  // { field: 'code', headerName: 'Coupon Code', flex: isMobile ? undefined : 1,
  //    renderCell: (params) => (
  //              <span style={{color:'#37ad52', fontWeight:600}}>
  //                {params.value}
  //              </span>
  //              ),
  //  },
 
  // { field: 'minamount', headerName: 'Min Amount', flex: isMobile ? undefined : 1,
  //    renderCell: (params) => (
  //              <>
  //                <CurrencyRupee sx={{ verticalAlign: 'middle', mr: 0.5, fontSize:'16px', marginBottom:'2px' }} />
  //                {params.value}
  //              </>
  //              ),
  //  },
 
   {
    field: 'generateIssued',
    headerName: 'Generate/Issued',
    flex: isMobile ? undefined : 1.5,
    align: 'center',
    renderCell: (params) => `${params.row.generate} / ${params.row.issued}`,
  },
  { field: 'redemption', headerName: 'Redemption',flex: isMobile ? undefined : 1,align: 'center',
     renderCell: (params) => (
      <>
      <span onClick={() => navigate('/redeemed')} style={{cursor:'pointer'}}>{params.value}</span>
      </>
     )
  },
   { field: 'status', headerName: 'Status', flex: isMobile ? undefined : 1, minWidth: 140, 
     renderCell: (params) => <Status status={params.value} />,
  },
  {
    field:'Action', headername:'Action', flex: isMobile ? undefined : 1, minWidth: 140, 
     renderCell: (params) => 
      <Button onClick={() => {
            setSelectedRow(params.row); // store row
            setOpen(true);              // open dialog
          }}><Info /></Button>
  }
  
];



  return (
    <Container sx={{my:2}}>
        {loading && <GradientLoader text="Loading" />}        {/* // loader */}
        {/* Back Button */}
      <Box sx={{ display: 'flex', justifyContent: 'flex-start', mb: 2 }}>
        <Button
          variant="contained"
          sx={{ backgroundColor: '#000000', color: '#ffffff' }}
          onClick={() => navigate(-1)}
        >
          Back
        </Button>
      </Box>
      {/* Title */}
      <Typography
        variant="h6"
        gutterBottom
        sx={{
          background: 'linear-gradient(195deg, #49a3f1, #1A73E8)',
          p: 1,
          color: '#ffffff',
          borderRadius: '4px',
          mb: 3,
          display: 'flex',
          alignItems: 'center'
        }}
      >
       Coupon List
      </Typography>
      <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 2 }}>
        <Button
          variant="contained"
          sx={{ background:'linear-gradient(195deg, #49a3f1, #1A73E8)', color: '#ffffff' }}
          onClick={() => navigate('/createcoupon')}
        >
         <Add/> Create Coupon
        </Button>
      </Box>
    

      {/* DataGrid */}
      <Box sx={{ height: 'auto',  width: '100%', mb:4 }}>
        <DataGrid
          apiRef={apiRef}  
          rows={datar}
          columns={columns}
          paginationMode="server"
          rowCount={totalRowCount}
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          pageSizeOptions={[PAGE_SIZE]}
           getRowHeight={() => 'auto'} 
          slots={{
            pagination: () => <CustomPagination apiRef={apiRef} isMobile={isMobile} />,
          }}
          sx={{
             '& .MuiDataGrid-cell': {
               whiteSpace: 'normal',     // Allow wrapping
               lineHeight:'20px',
               wordBreak: 'break-word', 
               display: 'flex',
              alignItems: 'center', // Vertically center content
              padding:'5px',
              gap: '4px'},
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: '#f0f0f0',
              color: '#000',
              fontWeight: 'bold',
            },
            '& .MuiDataGrid-columnHeaderTitle': {
              fontSize: 14,
              fontWeight: '600',
               whiteSpace: 'normal',
              wordBreak: 'break-word'
            },
          }}
          showToolbar
        />
      </Box>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth sx={{overflowY:'auto'}}>
        
        <Box>
          {selectedRow ? (
            <>
             <DialogTitle sx={{background:'linear-gradient(195deg, #49a3f1, #1A73E8)', color:'#fff'}}>
           <Typography variant="h6" gutterBottom >
                {selectedRow.ctitle}
              </Typography>
        </DialogTitle>
        <DialogContent >
           <Typography sx={{borderBottom:'1px solid #eee', py:1}}><b>Coupon Value:</b> {selectedRow.cvalue}</Typography>
              <Typography sx={{borderBottom:'1px solid #eee',py:1}}><b>Short Description:</b> {selectedRow.shortd}</Typography>
              <Typography sx={{borderBottom:'1px solid #eee', py:1}}><b>Long Description:</b> {selectedRow.longd}</Typography>
              {selectedRow.offimg && selectedRow.offimg !== "NA" && (
                <Box mt={2}>
                  <ImagePreview src={selectedRow.offimg} />

                </Box>
              )}
             </DialogContent>
             <DialogActions>
                <Box sx={{ textAlign: "right", mt: 2 }}>
                <Button onClick={() => setOpen(false)} variant="contained">
                  Close
                </Button>
              </Box>
             </DialogActions>
              
            </>
          ) : (
            <Typography>No details available</Typography>
          )}
        </Box>
      </Dialog>
    </Container>
  );
}

